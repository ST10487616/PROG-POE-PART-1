/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package login.poe;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_Lab
 */
public class MessageTestTest {
    
    public MessageTestTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of setUpClass method, of class MessageTest.
     */
    @Test
    public void testSetUpClass() {
        System.out.println("setUpClass");
        MessageTest.setUpClass();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of tearDownClass method, of class MessageTest.
     */
    @Test
    public void testTearDownClass() {
        System.out.println("tearDownClass");
        MessageTest.tearDownClass();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setUp method, of class MessageTest.
     */
    @Test
    public void testSetUp() {
        System.out.println("setUp");
        MessageTest instance = new MessageTest();
        instance.setUp();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of tearDown method, of class MessageTest.
     */
    @Test
    public void testTearDown() {
        System.out.println("tearDown");
        MessageTest instance = new MessageTest();
        instance.tearDown();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testGetMessageID method, of class MessageTest.
     */
    @Test
    public void testTestGetMessageID() {
        System.out.println("testGetMessageID");
        MessageTest instance = new MessageTest();
        instance.testGetMessageID();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testGetMessage method, of class MessageTest.
     */
    @Test
    public void testTestGetMessage() {
        System.out.println("testGetMessage");
        MessageTest instance = new MessageTest();
        instance.testGetMessage();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testGetRecipient method, of class MessageTest.
     */
    @Test
    public void testTestGetRecipient() {
        System.out.println("testGetRecipient");
        MessageTest instance = new MessageTest();
        instance.testGetRecipient();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testGetNumMessagesSent method, of class MessageTest.
     */
    @Test
    public void testTestGetNumMessagesSent() {
        System.out.println("testGetNumMessagesSent");
        MessageTest instance = new MessageTest();
        instance.testGetNumMessagesSent();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testSetNumMessagesSent method, of class MessageTest.
     */
    @Test
    public void testTestSetNumMessagesSent() {
        System.out.println("testSetNumMessagesSent");
        MessageTest instance = new MessageTest();
        instance.testSetNumMessagesSent();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testSetMessageHash method, of class MessageTest.
     */
    @Test
    public void testTestSetMessageHash() {
        System.out.println("testSetMessageHash");
        MessageTest instance = new MessageTest();
        instance.testSetMessageHash();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testCheckMessageID method, of class MessageTest.
     */
    @Test
    public void testTestCheckMessageID() {
        System.out.println("testCheckMessageID");
        MessageTest instance = new MessageTest();
        instance.testCheckMessageID();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testCheckMessageLength method, of class MessageTest.
     */
    @Test
    public void testTestCheckMessageLength() {
        System.out.println("testCheckMessageLength");
        MessageTest instance = new MessageTest();
        instance.testCheckMessageLength();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testCheckRecipientCell method, of class MessageTest.
     */
    @Test
    public void testTestCheckRecipientCell() {
        System.out.println("testCheckRecipientCell");
        MessageTest instance = new MessageTest();
        instance.testCheckRecipientCell();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testCreateMessageHash method, of class MessageTest.
     */
    @Test
    public void testTestCreateMessageHash() {
        System.out.println("testCreateMessageHash");
        MessageTest instance = new MessageTest();
        instance.testCreateMessageHash();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testSentMessage method, of class MessageTest.
     */
    @Test
    public void testTestSentMessage() {
        System.out.println("testSentMessage");
        MessageTest instance = new MessageTest();
        instance.testSentMessage();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testStoreMessage method, of class MessageTest.
     */
    @Test
    public void testTestStoreMessage() {
        System.out.println("testStoreMessage");
        MessageTest instance = new MessageTest();
        instance.testStoreMessage();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testPrintMessageDetails method, of class MessageTest.
     */
    @Test
    public void testTestPrintMessageDetails() {
        System.out.println("testPrintMessageDetails");
        MessageTest instance = new MessageTest();
        instance.testPrintMessageDetails();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testReturnTotalMessages method, of class MessageTest.
     */
    @Test
    public void testTestReturnTotalMessages() {
        System.out.println("testReturnTotalMessages");
        MessageTest instance = new MessageTest();
        instance.testReturnTotalMessages();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
