package login.poe;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.*;

public class ChatAppGUI extends JFrame {
    // Removed firstNameField and lastNameField
    private JTextField usernameField, phoneField;
    private JPasswordField passwordField;
    private JTextArea outputArea;
    private final JButton registerButton;
    private final JButton loginButton;

    // Store registered credentials
    private String storedUsername;
    private String storedPassword;
    // Removed storedFirstName and storedLastName

    // List to store messages
    private final List<Message> sentMessages = new ArrayList<>();
    // Counter for message ID and number of messages sent
    private int messageCounter = 0;

    public ChatAppGUI() {
        setTitle("Chat App Registration & Login");
        setSize(450, 450);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        // Changed GridLayout from 9 to 7 rows
        setLayout(new GridLayout(7, 2));

        // Removed "First Name" and "Last Name" input fields

        add(new JLabel("Username:"));
        usernameField = new JTextField();
        add(usernameField);

        add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        add(passwordField);

        add(new JLabel("Cell Phone (+27...):"));
        phoneField = new JTextField();
        add(phoneField);

        registerButton = new JButton("Register");
        loginButton = new JButton("Login");
        add(registerButton);
        add(loginButton);

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        add(new JScrollPane(outputArea)); // Use JScrollPane for JTextArea

        // Register button logic
        registerButton.addActionListener(e -> {
            // Removed String firstName and lastName extraction
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String phone = phoneField.getText();

            // Updated Login constructor call
            Login user = new Login(username, password, phone);
            String result = user.registerUser();
            outputArea.setText(result);

            if (result.equals("User registered successfully.")) {
                storedUsername = username;
                storedPassword = password;
                // Removed setting storedFirstName and storedLastName
            }
        });

        // Login button logic
        loginButton.addActionListener(e -> {
            String inputUsername = usernameField.getText();
            String inputPassword = new String(passwordField.getPassword());

            if (inputUsername.equals(storedUsername) && inputPassword.equals(storedPassword)) {
                // Updated welcome message
                JOptionPane.showMessageDialog(null, "Welcome, it is great to see you again.", "Login Success", JOptionPane.INFORMATION_MESSAGE);
                this.setVisible(false); // Hide login screen
                showChatMenu(); // Show the chat application menu
            } else {
                outputArea.setText("Username or password incorrect, please try again.");
            }
        });

        setVisible(true);
    }

    private void showChatMenu() {
        int choice;
        int totalMessagesToSend;
        boolean loggedIn = true;
        
        // 2. Welcome Message
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.", "QuickChat", JOptionPane.INFORMATION_MESSAGE);

        try {
            // 5. Define number of messages
            String numMessagesStr = JOptionPane.showInputDialog(null, "How many messages do you wish to enter?", "Message Count", JOptionPane.QUESTION_MESSAGE);
            if (numMessagesStr == null) return; // User cancelled
            totalMessagesToSend = Integer.parseInt(numMessagesStr.trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid number entered. Exiting.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 4. Application runs until quit
        while (loggedIn) {
            String menu = "Please choose a feature:\n" +
                          "1) Send Messages\n" +
                          "2) Show recently sent messages (Coming Soon)\n" + // 3b. Coming Soon
                          "3) Quit";
            
            String choiceStr = JOptionPane.showInputDialog(null, menu, "QuickChat Menu", JOptionPane.QUESTION_MESSAGE);
            
            if (choiceStr == null) {
                choice = 3; // Treat dialog closure as quit
            } else {
                try {
                    choice = Integer.parseInt(choiceStr.trim());
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please enter 1, 2, or 3.", "Error", JOptionPane.ERROR_MESSAGE);
                    continue;
                }
            }

            switch (choice) {
                case 1:
                    // Option 1: Send Messages
                    if (messageCounter >= totalMessagesToSend) {
                        JOptionPane.showMessageDialog(null, "You have reached the limit of " + totalMessagesToSend + " messages.\nTotal messages sent: " + messageCounter, "Message Limit Reached", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    }
                    
                    String messageID = String.format("%010d", new Random().nextInt(1000000000));
                    
                    String recipient = JOptionPane.showInputDialog("Enter Recipient Cell Number (+27... or 0...):");
                    if (recipient == null) break;
                    
                    String messageText = JOptionPane.showInputDialog("Enter Message (max 250 characters):");
                    if (messageText == null) break;
                    
                    Message currentMessage = new Message(messageID, messageCounter, recipient, messageText);
                    
                    String messageValidation = currentMessage.checkMessageLength();
                    String recipientValidation = currentMessage.checkRecipientCell();
                    
                    if (messageValidation.startsWith("Message ready to send.") || messageValidation.equals("Message sent") ) {
                        if (recipientValidation.startsWith("Cell phone number successfully captured.")) {
                            
                            String messageHash = currentMessage.createMessageHash();
                            currentMessage.setMessageHash(messageHash); 
                            
                            String actionResult = currentMessage.SentMessage();
                            
                            if (actionResult.equals("Message successfully sent.")) {
                                messageCounter++; 
                                currentMessage.setNumMessagesSent(messageCounter); 
                                sentMessages.add(currentMessage);
                                
                                JOptionPane.showMessageDialog(null, currentMessage.printMessageDetails(), "Message Sent", JOptionPane.INFORMATION_MESSAGE);
                            
                            } else if (actionResult.equals("Message successfully stored.")) {
                                currentMessage.storeMessage(currentMessage); 
                                JOptionPane.showMessageDialog(null, "Message successfully stored. Press O to delete message.", "Message Stored", JOptionPane.INFORMATION_MESSAGE);

                            } else { // Disregard Message
                                JOptionPane.showMessageDialog(null, "Message disregarded.", "Message Discarded", JOptionPane.INFORMATION_MESSAGE);
                            }
                            
                        } else {
                            JOptionPane.showMessageDialog(null, recipientValidation, "Validation Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                         JOptionPane.showMessageDialog(null, messageValidation, "Validation Error", JOptionPane.ERROR_MESSAGE);
                    }
                    
                    if (messageCounter == totalMessagesToSend) {
                         JOptionPane.showMessageDialog(null, "All " + totalMessagesToSend + " messages have been sent.\nTotal messages sent: " + messageCounter, "Session Complete", JOptionPane.INFORMATION_MESSAGE);
                    }
                    
                    break;
                case 2:
                    // Option 2: Show recently sent messages
                    JOptionPane.showMessageDialog(null, "Coming Soon.", "Feature Status", JOptionPane.INFORMATION_MESSAGE);
                    JOptionPane.showMessageDialog(null, printMessages(), "Sent Messages List", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 3:
                    // Option 3: Quit
                    loggedIn = false;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please enter 1, 2, or 3.", "Error", JOptionPane.ERROR_MESSAGE);
                    break;
            }
        }

        // Final summary on exit
        JOptionPane.showMessageDialog(null, "Total messages sent during this session: " + returnTotalMessages(), "Summary", JOptionPane.INFORMATION_MESSAGE);
        System.exit(0);
    }
    
    // Helper method to print all messages sent
    private String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }
        StringBuilder sb = new StringBuilder("Sent Messages:\n");
        for (int i = 0; i < sentMessages.size(); i++) {
            sb.append("\n--- Message ").append(i + 1).append(" ---\n");
            sb.append(sentMessages.get(i).printMessageDetails());
        }
        return sb.toString();
    }
    
    // Helper method to return total messages sent
    private int returnTotalMessages() {
        return sentMessages.size();
    }


    public static void main(String[] args) {
        // MessageTest.runTests(); 
        new ChatAppGUI();
    }
}

// Login class for validation (first name/last name removed)
class Login {
    private final String username;
    private final String password;
    private final String cellPhoneNumber;
    // Removed firstName and lastName fields

    // Updated constructor
    public Login(String username, String password, String cellPhoneNumber) {
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }

    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity() {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*\\d.*") &&
               password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
    }

    public boolean checkCellPhoneNumber() {
        Pattern pattern = Pattern.compile("^\\+27\\d{9}$");
        Matcher matcher = pattern.matcher(cellPhoneNumber);
        return matcher.matches();
    }

    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        return "User registered successfully.";
    }
}

/**
 * Message class for managing message-related data and logic.
 */
class Message {
    private String messageID;
    private int numMessagesSent; 
    private String recipient;
    private String message;
    private String messageHash; 

    private static final int MAX_MESSAGE_LENGTH = 250;
    
    private static final List<Message> storedMessages = new ArrayList<>();
    private static final String JSON_FILE_NAME = "stored_messages.json";


    public Message(String messageID, int numMessagesSent, String recipient, String message) {
        this.messageID = messageID;
        this.numMessagesSent = numMessagesSent;
        this.recipient = recipient;
        this.message = message;
    }
    
    // Getters and Setters
    public String getMessageID() { return messageID; }
    public String getMessage() { return message; }
    public String getRecipient() { return recipient; }
    public int getNumMessagesSent() { return numMessagesSent; }
    public void setNumMessagesSent(int numMessagesSent) { this.numMessagesSent = numMessagesSent; }
    public void setMessageHash(String messageHash) { this.messageHash = messageHash; }
    
    /**
     * Boolean: checkMessagelD() - This method ensures that the message ID is not more than ten characters.
     */
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }
    
    /**
     * Checks if the message is not more than 250 characters.
     */
    public String checkMessageLength() {
        if (message.length() <= MAX_MESSAGE_LENGTH) {
            if (message.length() <= 50) {
                 return "Message sent"; 
            }
            return "Message ready to send."; 
        } else {
            int excess = message.length() - MAX_MESSAGE_LENGTH;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }
    }

    /**
     * Int: checkRecipientCell() - This method ensures the cell number is correctly formatted (SA international).
     */
    public String checkRecipientCell() {
        Pattern internationalPattern = Pattern.compile("^\\+27\\d{9}$"); 
        Matcher intMatcher = internationalPattern.matcher(recipient);
        
        if (intMatcher.matches()) {
            return "Cell phone number successfully captured.";
        }
        
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    /**
     * String: createMessageHash() - Creates and returns the Message Hash.
     */
    public String createMessageHash() {
        if (messageID == null || message.isEmpty()) return "";

        String firstTwoID = messageID.substring(0, Math.min(2, messageID.length()));
        String numSent = String.valueOf(this.numMessagesSent); 

        String[] words = message.replaceAll("[^a-zA-Z0-9 ]", "").split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : (words.length == 1 ? words[0] : "");
        
        String hash = firstTwoID + ":" + numSent + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }

    /**
     * String:SentMessage() - Prompts the user to choose an action.
     */
    public String SentMessage() {
        Object[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
        int choice = JOptionPane.showOptionDialog(null, 
            "Select an action for this message:", 
            "Message Action", 
            JOptionPane.YES_NO_CANCEL_OPTION, 
            JOptionPane.QUESTION_MESSAGE, 
            null, 
            options, 
            options[0]);

        switch (choice) {
            case JOptionPane.YES_OPTION: 
                return "Message successfully sent."; 
            case JOptionPane.NO_OPTION: 
                return "Message disregarded."; 
            case JOptionPane.CANCEL_OPTION: 
                return "Message successfully stored."; 
            default:
                return "Action cancelled.";
        }
    }
    
    /**
     * storeMessage() - Stores the message in a JSON file.
     */
    public void storeMessage(Message message) {
        String jsonMessage;
        jsonMessage = String.format(
                "{\n" +
                        "  \"messageID\": \"%s\",\n" +
                        "  \"numMessagesSent\": %d,\n" +
                        "  \"recipient\": \"%s\",\n" +
                        "  \"messageHash\": \"%s\",\n" +
                        "  \"message\": \"%s\"\n" +
                        "}",
                message.getMessageID(),
                message.getNumMessagesSent(),
                message.getRecipient(),
                message.getMessageHash(), 
                message.getMessage().replace("\"", "\\\"")
        );

        try (PrintWriter writer = new PrintWriter(new FileWriter(JSON_FILE_NAME, true))) {
            writer.println(jsonMessage + ",");
            JOptionPane.showMessageDialog(null, "Message stored successfully to " + JSON_FILE_NAME, "Storage Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error storing message to JSON file: " + e.getMessage(), "Storage Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * String: printMessageDetails() - Returns a formatted string with message details.
     */
    public String printMessageDetails() {
        return "Message ID: " + messageID + 
               "\nMessage Hash: " + messageHash + 
               "\nRecipient: " + recipient + 
               "\nMessage: " + message; 
    }
    
    /**
     * Int: returnTotalMessagess() - This method returns the total number of messages stored.
     */
    public int returnTotalMessages() {
        return storedMessages.size();
    }
}


// --- Unit Test Class (As provided previously) ---

class MessageTest {
    
    public static final String TEST_ID_1 = "0012345678"; 
    public static final String TEST_RECIPIENT_1 = "+27718693002";
    public static final String TEST_MESSAGE_1 = "Hi Mike, can you join us for dinner tonight";
    public static final String EXPECTED_HASH_1 = "00:0:HITONIGHT"; 
    
    public static final String TEST_ID_2 = "1112345678";
    public static final String TEST_RECIPIENT_2_FAIL = "08575975889"; 
    public static final String TEST_MESSAGE_2 = "Hi Keegan, did you receive the payment?";
    
    public static final String TEST_ID_3 = "2212345678";
    public static final String TEST_MESSAGE_3_LONG = "a".repeat(251); 

    public static void runTests() {
        System.out.println("--- Running Unit Tests ---");
        
        Message test1 = new Message(TEST_ID_1, 0, TEST_RECIPIENT_1, TEST_MESSAGE_1);
        Message test2 = new Message(TEST_ID_2, 1, TEST_RECIPIENT_2_FAIL, TEST_MESSAGE_2);
        Message test3 = new Message(TEST_ID_3, 2, TEST_RECIPIENT_1, TEST_MESSAGE_3_LONG);
        
        testCheckMessageLengthSuccess(test1);
        testCheckMessageLengthFailure(test3);
        testCheckRecipientCellSuccess(test1);
        testCheckRecipientCellFailure(test2);
        testCreateMessageHash(test1);
        
        System.out.println("--- Tests Complete ---");
    }

    public static void testCheckMessageLengthSuccess(Message message) {
        String expected = "Message sent"; 
        String actual = message.checkMessageLength();
        System.out.println("Test 1 (Length Success): Expected: " + expected + ", Actual: " + actual + " -> " + (expected.equals(actual) ? "SUCCESS" : "FAILURE"));
    }

    public static void testCheckMessageLengthFailure(Message message) {
        String expected = "Message exceeds 250 characters by 1, please reduce size.";
        String actual = message.checkMessageLength();
        System.out.println("Test 2 (Length Failure): Expected: " + expected + ", Actual: " + actual + " -> " + (expected.equals(actual) ? "SUCCESS" : "FAILURE"));
    }
    
    public static void testCheckRecipientCellSuccess(Message message) {
        String expected = "Cell phone number successfully captured.";
        String actual = message.checkRecipientCell();
        System.out.println("Test 3 (Recipient Success): Expected: " + expected + ", Actual: " + actual + " -> " + (expected.equals(actual) ? "SUCCESS" : "FAILURE"));
    }
    
    public static void testCheckRecipientCellFailure(Message message) {
        String expected = "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        String actual = message.checkRecipientCell();
        System.out.println("Test 4 (Recipient Failure): Expected: " + expected + ", Actual: " + actual + " -> " + (expected.equals(actual) ? "SUCCESS" : "FAILURE"));
    }
    
    public static void testCreateMessageHash(Message message) {
        String expected = "00:0:HITONIGHT"; 
        String actual = message.createMessageHash();
        System.out.println("Test 5 (Hash): Expected: " + expected + ", Actual: " + actual + " -> " + (expected.equals(actual) ? "SUCCESS" : "FAILURE"));
    }
}